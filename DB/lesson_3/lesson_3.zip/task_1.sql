alter table streams rename column start_date to started_at;

