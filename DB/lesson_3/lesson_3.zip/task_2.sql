alter table streams add column finished_at text;

