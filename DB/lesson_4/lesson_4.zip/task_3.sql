select distinct substr(started_at, 1, 4) as "year" from streams; 
