select count(*) as "total_teachers" from teachers;

