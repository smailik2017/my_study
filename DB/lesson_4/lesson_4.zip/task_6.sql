select avg(performance) from grades where teacher_id = 1;
