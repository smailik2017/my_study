select teacher_id from grades group by teacher_id having avg(performance) < 4.8; 
