select id, "number" from streams order by started_at desc limit 1;
