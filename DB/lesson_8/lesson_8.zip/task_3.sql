create index streams_number_idx on streams(number);
 
